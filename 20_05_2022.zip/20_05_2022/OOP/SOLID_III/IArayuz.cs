﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_III
{
    public interface IArayuz
    {
        void Uc();
        void Yuru();
        void Kos();
        void Yuz();
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_III
{
    public class Kaleci : IKaleci
    {
        public void ElleOyna()
        {
            throw new NotImplementedException();
        }

        public void PenaltiAt()
        {
            throw new NotImplementedException();
        }

        public void Sut()
        {
            throw new NotImplementedException();
        }

        public void TopSur()
        {
            throw new NotImplementedException();
        }
    }
}

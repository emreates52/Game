﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_II
{
    public class Personel
    {
        public virtual void MaasHesapla()
        {
            Console.WriteLine("Personel Maas Hesaplamasi...");
        }
    }
}
